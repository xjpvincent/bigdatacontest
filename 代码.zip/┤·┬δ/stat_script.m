%
vector_news=vector_news*10000;
class_center1=mean(vector_news(find(newstype_num==1),:),1);
d_new1=[]
for i=1:length(newstype_num)
    d_new1(end+1)=sqrt(sum((vector_news(i,:)-class_center1).^2));
end
[x y]=sort(d_new1);
y=rot90(rot90(y));
y=y';

for i=1:length(news_wordscount)
    vector_news(i,:)=vector_news(i,:)/news_wordscount(i);
end

sum_mean=sum(bin_vector_news')';
index_s=find(sum_mean<50&sum_mean>25);
index_w=find(news_wordscount>500&news_wordscount<5000);

xx=intersect(index_s,index_w);

xxx=find(news_wordscount)

[ s v d]=svd()