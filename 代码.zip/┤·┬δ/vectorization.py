# -*- coding : utf-8 -*-
import sys
import MySQLdb as mdb
import nltk
import operator
import time
#reload(sys) 
#sys.setdefaultencoding('utf-8') 
filename='dict_words_first'+time.strftime('%Y_%m_%d_%H_%M_%S', time.gmtime(time.time()))+'.txt'
f=open(filename,'w')
dict_words={}
try:    
    conn=mdb.connect(host='localhost',
                     user='root',
                     passwd='',
                     db='comp',
                     charset='utf8')
    cur=conn.cursor()
    win_len=50
    step_len=500
    for i in range(155,157):
        print  i
        cur.execute("select segresult from t_lable_group_comp where source_type=0  LIMIT %d,%d"%(i*step_len,win_len))
        datas=cur.fetchall()
        for data in datas:
           # print data[0].encode('utf8')  
            tmps=data[0].encode('utf8').split()

            for tmp in tmps:
                tmp1=nltk.tag.str2tuple(tmp)
                if dict_words.has_key(tmp1[0]):
                    dict_words[tmp1[0]]=dict_words[tmp1[0]]+1
                else:
                    dict_words[tmp1[0]]=1
    

   # for data in datas:
  #     print "Database :%s"%data[0].encode("utf-8") 
  
finally:   
    if conn:
        conn.close()


filename='dict_words_last_'+time.strftime('%Y_%m_%d_%H_%M_%S', time.gmtime(time.time()))+'.txt'
ff=open(filename,'w')

words=dict_words.keys()
#sort
sorted_words=sorted(dict_words.iteritems(), key=operator.itemgetter(1), reverse=True)
print type(sorted_words)
for word in sorted_words:
    ff.write(word[0]+':%d \n'%word[1])