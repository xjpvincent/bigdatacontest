# coding=utf-8
import sys
import MySQLdb as mdb
import nltk
import operator
import codecs
import random

rubish_list=[]

for line in open("rubish_id_test.txt"):
    rubish_list.append(line.split()[0])

try:    
    conn=mdb.connect(host='localhost',
                     user='root',
                     passwd='',
                     db='comp',
                     charset='utf8')
    cur=conn.cursor() 
    i=1
    for id in rubish_list:        
        i=i+1
        print i
        cur.execute("delete  from t_lable_group_comp where id='%s' "%(id))
finally:   
    if conn:
        conn.close()
print 'down'
