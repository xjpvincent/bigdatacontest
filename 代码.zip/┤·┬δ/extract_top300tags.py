# coding=utf-8
import sys
import MySQLdb as mdb
import nltk
import operator
import codecs
import random
word_list=[]
for line in open('words_filter.txt'):
	tmp=line.split()
	word_list.append(tmp[0])
	

top300=[]

for line in open('top300.txt'):
	tmp=line.split()
	top300.append(int(tmp[0]))
	#print tmp[0]

f=open('top300_words.txt','w')

for i in range(300):
	print top300[i]
	tmp=word_list[top300[i]-1]
	f.write(tmp+'\n')