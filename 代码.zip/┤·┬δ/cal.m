[h p1 c]=ttest2(sample_news1,sample_news2);
[h p2 c]=ttest2(sample_news1,sample_news3);
[h p3 c]=ttest2(sample_news2,sample_news3);
p1_sort=sort(p1);
p2_sort=sort(p2);
p3_sort=sort(p3);
index=zeros(3000,1)
for i=0:1000
    index(i*3+1)=find(p1==p1_sort(i+1));
    index(i*3+2)=find(p2==p2_sort(i+1));
    index(i*3+3)=find(p3==p3_sort(i+1));
end
unique_index=[];
for i=1:length(index)
    if isempty(find(unique_index==index(i)))
     unique_index(end+1)=index(i);
    end
end
unique_index=unique_index';
