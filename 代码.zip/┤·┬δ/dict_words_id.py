# -*- coding : utf-8 -*-
#BigData Contest
#author:xjp:xjpvincent@163.com
import sys
import MySQLdb as mdb
import nltk
import operator
import time
#reload(sys) 
#sys.setdefaultencoding('utf-8') 

filename='dict_words_first'+time.strftime('%Y_%m_%d_%H_%M_%S', time.gmtime(time.time()))+'.txt'
f=open(filename,'w')
dict_words={}

id_list=[]

for line in open("id_news.txt"):
    id_list.append(line.split()[0])

try:    
    conn=mdb.connect(host='localhost',
                     user='root',
                     passwd='',
                     db='comp',
                     charset='utf8')
    cur=conn.cursor() 
    list_len=len(id_list)
    for id_word in range(1):      
        cur.execute("select segresult from t_lable_group_comp where id='%s' "%(id_list[id_word]))   
        items=cur.fetchone()
        tmps=items[0].encode('utf8').split()
        for tmp in tmps:
            tmp1=nltk.tag.str2tuple(tmp)
            if dict_words.has_key(tmp1[0]):
                dict_words[tmp1[0]]=dict_words[tmp1[0]]+1
            else:
                dict_words[tmp1[0]]=1

        conn.close()
        if id_word%1000==0:
            print id_word
finally:   

    if conn:

filename='dict_newswords_last_'+time.strftime('%Y_%m_%d_%H_%M_%S', time.gmtime(time.time()))+'.txt'
ff=open(filename,'w')

words=dict_words.keys()
#sort
sorted_words=sorted(dict_words.iteritems(), key=operator.itemgetter(1), reverse=True)

print type(sorted_words)

for word in sorted_words:
    pass

    #ff.write(word[0]+'/%d/%s\n'%(5,word[1])