# coding=utf-8
import sys
import MySQLdb as mdb

f=open('xiaoyuan_weibo_id.txt','w')
print 'begin'

try:    
    conn=mdb.connect(host='localhost',
                     user='root',
                     passwd='',
                     db='comp',
                     charset='utf8')
    cur=conn.cursor()
    print 'xxxx'
    cur.execute("select id from t_lable_group_comp where source_type=4 and hit_tag='%s'  order by release_date_day asc " % "校园砍伤事件")
    items=cur.fetchall()
    i=0
    print 'xxxxsssdfsf'
  
    for item in items:
        
    	f.write(str(item[0]) +'\n')
        if i%1000==0:
            print i
        i=i+1
    print 'down'

finally:   
    if conn:
    	conn.close()
f.close()


##do words stat



		