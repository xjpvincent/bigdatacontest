# coding=utf-8
import sys
import operator

f1=open('words_list.txt','r')

words_type={}
words_list={}
for line in open('words_type.txt'):
	tmp=line.split()
	words_type[line[0]]=1

for line in open('words_list.txt'):
	tmp=line.split()
	#print tmp

	#print tmp[0]
	if words_type.has_key(tmp[2]):
		tmp[1]=int(tmp[1])
		words_list[tmp[0]]=(tmp[1],tmp[2])
		#print words_list[tmp[0]]

	#	print len(words_list)b

f2=open('words_filter.txt','w')

f3=open('words_filter_num.txt','w')
sorted_words=sorted(words_list.iteritems(), key=operator.itemgetter(1), reverse=True)
for word in sorted_words:
	f2.write(word[0]+' %d %s\n' % (word[1][0],word[1][1]))
	f3.write('%d\n' % word[1][0])
#    f2.write(word[0]+' %d\n'%(word[1][0])
#	f2.write(item+' %s %s\n'%(sorted_words[item][1],sorted_words[item][2]))