# coding=utf-8
import sys
import MySQLdb as mdb
import nltk
import operator
import codecs
import random


id_list=[]

for line in open("id_news.txt"):
    id_list.append(line.split()[0])

try:    
    conn=mdb.connect(host='localhost',
                     user='root',
                     passwd='',
                     db='comp',
                     charset='utf8')
    cur=conn.cursor() 

    f = open('wordscount_news.txt', 'w')
    for id in id_list:        
        cur.execute("select words from t_lable_group_comp where id='%s' "%(id))
        items=cur.fetchone()        
        f.write(str(items[0])+'\n')
    f.close()
finally:   
    if conn:
        conn.close()
