import java.io.File;
import java.io.IOException;
import com.aliasi.classify.Classification;
import com.aliasi.classify.Classified;
import com.aliasi.classify.DynamicLMClassifier;
import com.aliasi.lm.NGramProcessLM;
import com.aliasi.util.Files;
import java.sql.*;
import java.io.*;

public class PolarityBasic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		       try {
		           new PolarityBasic().run();
			       } 
		       catch (Throwable t) {
		           System.out.println("Thrown: " + t);
		           t.printStackTrace(System.out);
			       }
	}
	
	
	File mPolarityDir;
    String[] mCategories;
    DynamicLMClassifier<NGramProcessLM> mClassifier;  

    PolarityBasic() {
        System.out.println("\nBASIC POLARITY DEMO");
        mPolarityDir = new File("POLARITY_DIR/txt_sentoken");   //��ȡPOLARITY_DIR/txt_sentoken�е����ϼ�
        mCategories = mPolarityDir.list();  //��ȡ���neg��pos
        int nGram = 8;
        mClassifier = DynamicLMClassifier.createNGramProcess(mCategories,nGram);  //ʹ��N-Gram���෽��
    }
	
  //�����ȵ���ѵ���������ٵ�����������
    void run() throws ClassNotFoundException, IOException {
        train();
        evaluate();
        sentimentAnalysisDatabase();
        evaluate();
    }

    //������Ҫһ�ݲ��Լ���һ��ѵ��������������ֻ��һ�����Ͽ⣬ֻ����Ϊ�ָ�
    //����ļ����ĵ�2λΪ9���� test set
    boolean isTrainingFile(File file) {       //�Ƿ���ѵ����
        return file.getName().charAt(6) != '9';  // test on fold 9
    }

    //������ѵ��
    void train() throws IOException {
        int numTrainingCases = 0;    //ѵ���ı���
        int numTrainingChars = 0;    //ѵ���ַ���
        System.out.println("\nTraining.");
        for (int i = 0; i < mCategories.length; ++i) {
            String category = mCategories[i];
            Classification classification = new Classification(category);
            File file = new File(mPolarityDir,mCategories[i]);
            File[] trainFiles = file.listFiles();
            for (int j = 0; j < trainFiles.length; ++j) {
                File trainFile = trainFiles[j];
                if (isTrainingFile(trainFile)) {   //�ж�һ����Ϊ����һ����������Ϊѵ������һ������Ϊ���Լ�                  
                    ++numTrainingCases;
                    String review = Files.readFromFile(trainFile,"GBK");    //�ı�����
                    numTrainingChars += review.length();
                    Classified<CharSequence> classified = 
                        new Classified<CharSequence>(review,classification); //ָ�����ݺ����
                    mClassifier.handle(classified);    //ѵ��
                }
            }
        }
        System.out.println("  # Training Cases=" + numTrainingCases);   //ѵ�����ļ���
        System.out.println("  # Training Chars=" + numTrainingChars);   //ѵ�����ַ��ܺ�
    }
    
  //����
    void evaluate() throws IOException {
        System.out.println("\nEvaluating.");
        int numTests = 0;
        int numCorrect = 0;
        for (int i = 0; i < mCategories.length; ++i) {
            String category = mCategories[i];
            File file = new File(mPolarityDir,mCategories[i]);
            File[] trainFiles = file.listFiles();
            for (int j = 0; j < trainFiles.length; ++j) {
                File trainFile = trainFiles[j];
                if (!isTrainingFile(trainFile)) {    //���Լ�
                    String review = Files.readFromFile(trainFile,"GBK");
                    ++numTests;
                    Classification classification = mClassifier.classify(review);    //�Բ��Լ��ı����з���
                    if (classification.bestCategory().equals(category)){        //�����������ı�������=�ı�ԭ��ע�����࣬����ȷ
                        ++numCorrect;    
                    }                       
                }
            }
        }
        System.out.println("  # Test Cases=" + numTests);    //�����ļ���
        System.out.println("  # Correct=" + numCorrect);     //��ȷ��
        System.out.println("  % Correct=" + ((double)numCorrect)/(double)numTests);   //��ȷ��
    }
    
    void sentimentAnalysisDatabase()
    {
    	int neg_index = 168;
    	int pos_index = 168;
    	int non_index = 668;
      try
      {
          System.out.println("Open database...\n");
        String url="jdbc:mysql://localhost/baiduBigData";
        String user="root";
        String pwd="root";
        
        //��������
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        //������MySQL������
        Connection conn = DriverManager.getConnection(url,user, pwd);
        
        //ִ��SQL���
        Statement stmt = conn.createStatement();//��������������ִ��sql����
        System.out.println("Execute SQL sentence...\n");
        ResultSet rs = stmt.executeQuery("SELECT id,format_content FROM baiduBigData.t_lable_group_comp where source_type = 4 && hit_tag = '��������ը'");
        System.out.println("Open result file...\n");
        FileWriter output = new FileWriter("gj_Weibo_sentiment.txt");
        BufferedWriter bf = new BufferedWriter(output);
         //���������
        System.out.println("Processing data...\n");
        while (rs.next())
        {
          String content = rs.getString("format_content");
          String content_ID = rs.getString("id");
          bf.write(content_ID+"\t");
          if(content==null)
          {
        	  bf.write("no data! \r\n");
        	  continue;
          }
          Classification classification = mClassifier.classify(((CharSequence)content));    //�Բ��Լ��ı����з���
          String m_category = classification.bestCategory();
          bf.write(m_category+"\r\n");
          bf.flush();
          if(m_category.contentEquals("non")&& non_index < 5000)
      	  {
    		    non_index=non_index +1;
    		    System.out.println("Adding new train data...\n");
    	        FileWriter retrain = new FileWriter("POLARITY_DIR/txt_sentoken/non/non_"+non_index+".txt");
    	        BufferedWriter retrain_bf = new BufferedWriter(retrain);
    	        retrain_bf.write(content);
    	        retrain_bf.close();
    	        retrain.close();
    		    System.out.println("Added.\n\n");
          }
          else
          {//������ѵ������
        	  if(m_category.contentEquals("pos") && pos_index < 5000)
        	  {
    		    pos_index=pos_index +1;
    		    System.out.println("Adding new train data...\n");
    	        FileWriter retrain = new FileWriter("POLARITY_DIR/txt_sentoken/pos/pos_"+pos_index+".txt");
    	        BufferedWriter retrain_bf = new BufferedWriter(retrain);
    	        retrain_bf.write(content);
    	        retrain_bf.close();
    	        retrain.close();
    		    System.out.println("Added.\n\n");
        	  }
        	  if(m_category.contentEquals("neg") && neg_index < 5000)
        	  {
      		    System.out.println("Adding new train data...\n");
      		    neg_index=neg_index +1;
    	        FileWriter retrain = new FileWriter("POLARITY_DIR/txt_sentoken/neg/neg_"+neg_index+".txt");
    	        BufferedWriter retrain_bf = new BufferedWriter(retrain);
    	        retrain_bf.write(content);
    	        retrain_bf.close();
    	        retrain.close();
    	        System.out.println("Added.\n\n");
        	  }
          }
        }
        bf.close();
        output.close();
        rs.close();//�ر����ݿ�
        conn.close();
        System.out.println("Done!\r\n");
      }
      catch (Exception ex)
      {
        System.out.println("Error : " + ex.toString());
      }
    }
    
}
