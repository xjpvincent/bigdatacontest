# coding=utf-8
import sys
import MySQLdb as mdb
import nltk
import operator
import codecs
import random


id_list1={}
id_list2={}
id_list3={}
id_list=[]
for line in open("id_news.txt"):
    id_list.append(line.split()[0])
for line in open("id_news1.txt"):
    id_list1[line.split()[0]]=1
for line in open("id_news2.txt"):
    id_list2[line.split()[0]]=1
for line in open("id_news3.txt"):
    id_list3[line.split()[0]]=1


f=open('newstype_num.txt','w')
for i in range(len(id_list)):
    if id_list1.has_key(id_list[i]):
        f.write(str(1))
    elif id_list2.has_key(id_list[i]):
        f.write(str(2))
    elif id_list3.has_key(id_list[i]):
        f.write(str(3))
    else:
        f.write(str(0))
    f.write('\n')
    
    if i%1000==0:
        print i







        
# try:    
#     conn=mdb.connect(host='localhost',
#                      user='root',
#                      passwd='',
#                      db='comp',
#                      charset='utf8')
#     cur=conn.cursor()
#     f=open('newstype.txt','w')
#     i=1
#     for id in id_list:   
#         i=i+1
#         dict_words={}            
#         cur.execute("select hit_tag from t_lable_group_comp where id='%s' "%(id)) 
#         items=cur.fetchone()
#         f.write(items[0].encode('utf8')+'\n')
#         if i%1000==0:
#             print i 
      
#     f.close()
# finally:   
#     if conn:
#         conn.close()