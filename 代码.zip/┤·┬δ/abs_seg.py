#encoding=utf-8
import jieba
import sys
import MySQLdb as mdb
import nltk
import operator
import codecs
import random
import re
import os

reload(sys)
sys.setdefaultencoding( "utf-8" )
sys.path.append("../")
jieba.load_userdict("words_filter.txt")

import jieba.posseg as pseg
import jieba.analyse
from optparse import OptionParser

# print type(seg_list)
# print ", ".join(seg_list)

# for word in seg_list:
# 	print word+ '|'

def get_idlist(filepath):
	id_list=[]
	for line in open(filepath):
	    id_list.append(line.split()[0])
	return id_list


def getconn():
	try:    

	    conn=mdb.connect(host='localhost',
	                     user='root',
	                     passwd='',
	                     db='comp',
	                     charset='utf8')   
	finally:   
	    return conn



def get_dayIDlist(id_list, day):
	pattern=re.compile(day)
	id_day_list=[]
	for item in id_list:
		if type(pattern.match(item))!=type(None):
			id_day_list.append(item)
	return id_day_list


def create_idfile(filename):
	f=open(filename,'w')

	try:    
	    conn=mdb.connect(host='localhost',
	                     user='root',
	                     passwd='',
	                     db='comp',
	                     charset='utf8')
	    cur=conn.cursor()

	    cur.execute("select id from t_lable_group_comp where source_type=0 ")
	    items=cur.fetchall()
	    for item in items:
	    	f.write(str(item[0]) +'\n')
	finally:   
	    if conn:
	    	conn.close()
	f.close()

def get_keywords_onDay(cur,id_list,day):
	id_day_list=get_dayIDlist(id_list,day)
	title=''
	abstract=''
	content=''
	for item in id_day_list:
		cur.execute("select title, abs, format_content from t_lable_group_comp where id='%s' "%(item))
		items=cur.fetchone()
		if type(items[0])!=type(None):
			title=title+items[0].encode("utf8")
		if type(items[1])!=type(None):
			abstract=abstract+items[1].encode("utf8")
		if type(items[0])!=type(None):
			content=content+items[2].encode("utf8")


	title_keywords=jieba.analyse.extract_tags(title, 15)
	abstract_keywords=jieba.analyse.extract_tags(abstract, 15)
	content_keywords=jieba.analyse.extract_tags(content, 15)
	return (title_keywords, abstract_keywords, content_keywords)


def get_titles_onDay(cur,id_list,day):	
	id_day_list=get_dayIDlist(id_list,day)
	print len(id_day_list)
	f=open('./titles/'+day+'_titles.txt','w')
	for item in id_day_list:
		cur.execute("select title from t_lable_group_comp where id='%s' "%(item))
		items=cur.fetchone()
		if type(items[0])!=type(None):
			f.write(item+' '+items[0].encode("utf8")+'\n')
	f.close()


		

def get_hightitle_day(cur,id_list,day):
	id_day_list=get_dayIDlist(id_list,day)
	title_dict={}
	for item in id_day_list:
		cur.execute("select title from t_lable_group_comp where id='%s' "%(item))
		items=cur.fetchone()
		if type(items[0])!=type(None):
			tmp=items[0].encode("utf8")
			if title_dict.has_key(tmp):
				title_dict[tmp]=title_dict[tmp]+1
			else:
				title_dict[tmp]=1
	sorted_title=sorted(title_dict.iteritems(), key=operator.itemgetter(1), reverse=True)
	return sorted_title



def write_file(tags,filename):
	f=open(filename,'w')
	for tag in tags:
		f.write(tag+'\n')
	f.close
	print 'down'

	     
def get_alltitle(id_list, date_list, day):
	keywords=get_keywords_onDay(id_list,day)
	title_keywords=keywords[0]
	f=open('test.txt','w')
	for key in title_keywords:
		f.write(key+'\n')
	index=date_list.index(day)
	conn=getconn()
	cur=conn.cursor()
	ff=open('test1.txt','w')

	for  index in range(index,len(id_list)):
		flag=0
		cur.execute("select title from t_lable_group_comp where id='%s'" % id_list[index])
		items=cur.fetchone()
		if type(items[0])==type(None):
			continue
		seg_list=jieba.cut(items[0].encode('utf8'))
		tmps=[]
		tmps.extend(seg_list)
		for tmp in tmps:
			if title_keywords.count(tmp)>0:
				flag=flag+1
		if flag>0:
			ff.write(date_list[index]+' '+items[0].encode('utf8')+'\n')
		index=index+1
		if index%100==0:
			print index,len(id_list)
		break

def get_alltitle_onEvent(cur, id_list, date_list, date_event,event_seed):
    if ~os.path.isfile(date_event):
    	os.makedirs(date_event)

	keywords=get_keywords_onEvent(cur,event_seed)
	title_keywords=keywords[0]	
	fkey=open('key.txt','w')
	for words in title_keywords:
		fkey.write(words)

	index=date_list.index(date_event)
	dict_date={}
	for item in date_list:
		dict_date[item[0:10]]=1
	dates=dict_date.keys()
	dates.sort()

    
	ff=open(date_event+'/'+'title.txt','w')
	ff1=open(date_event+'/'+'envent_id.txt','w')
	flag_day=0
	day_index=dates.index(date_event)
	while  (flag_day<15)&(day_index<len(dates)):
		id_list_day=get_dayIDlist(id_list, dates[day_index])
		tmp_day=0	

		for  id_day in id_list_day:
			flag=0
			cur.execute("select title from t_lable_group_comp where id='%s'" % id_day)
			items=cur.fetchone()
			if type(items[0])==type(None):
				continue
			seg_list=jieba.cut(items[0].encode('utf8'))
			
			tmps=[]
			tmps.extend(seg_list)
			for tmp in tmps:
				if title_keywords.count(tmp)>0:
					flag=flag+1
			if flag>1:
				ff.write(dates[day_index]+' '+items[0].encode('utf8')+'\n')
				ff1.write(id_day+'\n')
				tmp_day=tmp_day+1
		if tmp_day<1:
			flag_day=flag_day+1
			day_index=day_index+1
		else:
			day_index=day_index+1
		print dates[day_index]
	print flag_day	
	ff.close()
	ff1.close()

def get_keywords_onEvent(cur,event_seed):
	event_list=event_seed.split()
	title=''
	abstract=''
	content=''
	for item in event_list:
		cur.execute("select title, abs, format_content from t_lable_group_comp where id='%s' "%(item))
		items=cur.fetchone()
		if type(items[0])!=type(None):
			title=title+items[0].encode("utf8")
		if type(items[1])!=type(None):
			abstract=abstract+items[1].encode("utf8")
		if type(items[0])!=type(None):
			content=content+items[2].encode("utf8")


	title_keywords=jieba.analyse.extract_tags(title, 3)
	abstract_keywords=jieba.analyse.extract_tags(abstract, 3)
	content_keywords=jieba.analyse.extract_tags(content, 3)
	return (title_keywords, abstract_keywords, content_keywords)

def filter_title(cur,id_list,day,keywords):
	pass
def getalltitles_onday(id_list,date_list,cur):
	dict_date={}
	for item in date_list:
		dict_date[item[0:10]]=1
	dates=dict_date.keys()
	dates.sort()
	for date in dates:
		get_titles_onDay(cur,id_list,date)

def getallhightitles_onday(id_list,date_list,cur):
	dict_date={}
	for item in date_list:
		dict_date[item[0:10]]=1
	dates=dict_date.keys()
	f=open('hightitle_day.txt','w')
	dates.sort()
	for date in dates:
		print date
		sorted_title=get_hightitle_day(cur,id_list,date)
		f.write(date+' ')
		if len(sorted_title)<2:
			f.write('(1)'+sorted_title[0][0])
		elif len(sorted_title)<3:
			f.write('(1) '+sorted_title[0][0]+' ')
			f.write('(2) '+sorted_title[1][0])
		else:
			f.write('(1)'+sorted_title[0][0]+' ')
			f.write('(2)'+sorted_title[1][0]+' ')
			f.write('(3)'+sorted_title[2][0])
		f.write('\n')
	f.close()	

	
def calkeywords(filename):
	test=' '
	for line in open(filename):
		test=test+line
	keywords=jieba.analyse.extract_tags(test, 300)
	return keywords



# try:    
#     conn=getconn()
#     cur=conn.cursor()
#     cur.execute("select title,abs,format_content from t_lable_group_comp where id='2013_12_31293685885489119243' ")
#     tmp=cur.fetchone()
#     comtent=tmp[0].encode('utf8')
#     tags = jieba.analyse.extract_tags(comtent, 15)

#     #设定停用词
#    # jieba.analyse.set_stop_words("../exacta_dict/stop_words.txt")
#     #自定义语料库
#    # jieba.analyse.set_idf_path("../exacta_dict/idf.txt.")

#     f=open('tmp.txt','w')

#     for tag in tags:
#     	f.write(tag+'|')
# finally:   
#     if conn:
#         conn.close()

if __name__=="__main__":	
	# conn=getconn()
	# cur=conn.cursor()
	# id_list=get_idlist('baokong_id.txt')
	# #date_list=get_idlist("date.txt")
	# date_list=[]
	# for item in id_list:
	# 	date_list.append(item[0:10])
	
	# event_seed='2013_03_08293700936395653138'
	# date_event='2013_03_07'
	# keywords=get_keywords_onEvent(cur,event_seed)
	# title_keywords=keywords[0]	
	# fkey=open('key.txt','w')
	# for words in title_keywords:
	# 	fkey.write(words)
	# fkey.close()

	# get_alltitle_onEvent(cur, id_list, date_list, date_event,event_seed)
	f=open('keywords.txt','w')
	keywords=calkeywords('top300_words.txt')
  
	for keyword in keywords:
	    f.write(keyword+'\n')


    #print len(keywords)

	#keywords=get_keywords_onEvent(cur,'2014_03_01293687729639653391	2014_03_01293687940094099485	2014_03_02293687627634180101')
	
#	getalltitles_onday(id_list,date_list,cur)


	#getallhightitles_onday(id_list,date_list,cur)

	#get_alltitle(id_list, date_list, '2014_03_02')
#	sorted_title=get_hightitle_day(id_list,'2014_03_03')
	# f=open('title.txt','w')

	# for title in sorted_title:
	# 	f.write(title[0]+'   '+str(title[1]))
	# 	f.write('\n')
		
		# id_day_list=get_dayIDlist(id_list,'2014_03_03')
	# xx=get_keywords_onDay(id_list,'2014_03_06')
	# print xx[0],xx[1],xx[2]
	# write_file(xx[0],'title_tags.txt')
	# write_file(xx[1],'abstract_tags.txt')
	# write_file(xx[2],'content_tags.txt')
	# print 'down\n'