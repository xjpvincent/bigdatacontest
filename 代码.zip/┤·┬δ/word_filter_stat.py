# coding=utf-8
import sys
import MySQLdb as mdb
import nltk
import operator
import codecs
import random

word_list=[]
word_value=[]

for line in open('words_filter.txt'):
	tmp=line.split()
	word_list.append(tmp[0])
    #print tmp[0]

id_list1=[]
id_list2=[]
id_list3=[]

for line in open("id_news1.txt"):
    id_list1.append(line.split()[0])
for line in open("id_news2.txt"):
    id_list2.append(line.split()[0])
for line in open("id_news3.txt"):
    id_list3.append(line.split()[0])
def cal_wordfrequency(conn,word_list,id_list):
    cur=conn.cursor()
    dict_words={}
    for tmp in word_list:
        dict_words[tmp]=0
    word_value=range(len(word_list))
    for i in range(len(word_list)):
        word_value[i]=0
    for id in id_list:                  
        cur.execute("select segresult from t_lable_group_comp where id='%s' "%(id)) 
        items=cur.fetchone()
        tmps=items[0].encode('utf8').split()
        for tmp in tmps:
            tmp1=nltk.tag.str2tuple(tmp)
            if dict_words.has_key(tmp1[0]):                           
                dict_words[tmp1[0]]=dict_words[tmp1[0]]+1         
            else:
                pass
        # for tmp in tmps:
        #     tmp1=nltk.tag.str2tuple(tmp)
        #     # print tmp1[0]
        #     if word_list.count(tmp1[0])>0:
        #         index=word_list.index(tmp1[0])
        #         word_value[index]=word_value[index]+1

    for tmp in dict_words:
        index=word_list.index(tmp)
        word_value[index]=dict_words[tmp]
    return word_value
           

slice = random.sample(id_list1,1000)
for x in slice:
    pass#print x
try:    
    conn=mdb.connect(host='localhost',
                     user='root',
                     passwd='',
                     db='comp',
                     charset='utf8')
    cur=conn.cursor() 
    output1 = open('sample_news1.txt', 'a')
    # output2 = open('sample_news2.txt', 'w+')
    # output3 = open('sample_news3.txt', 'w+')
    for t in range(100):
        print t
        id_sample = random.sample(id_list1,1000)
        word_value=cal_wordfrequency(conn,word_list,id_sample)
        for i in word_value:
            output1.write(str(i) +' ')
        output1.write("\n")
 

    #list_len=len(id_list)
    # for id_word in range(1):      
    #     cur.execute("select segresult from t_lable_group_comp where id='%s' "%(id_list[id_word]))   
    #     items=cur.fetchone()
    #     tmps=items[0].encode('utf8').split()
    #     for tmp in tmps:
    #         tmp1=nltk.tag.str2tuple(tmp)
    #         if dict_words.has_key(tmp1[0]):
    #             dict_words[tmp1[0]]=dict_words[tmp1[0]]+1
    #         else:
    #             dict_words[tmp1[0]]=1

    #     if id_word%1000==0:
    #         print id_word

finally:   
    if conn:
        conn.close()
    if output1:
        output1.close()
