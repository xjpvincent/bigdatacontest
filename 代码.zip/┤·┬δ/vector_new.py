#encoding=utf-8
import jieba
import sys
import MySQLdb as mdb
import nltk
import operator
import codecs
import random
import re
import os

reload(sys)
sys.setdefaultencoding( "utf-8" )
sys.path.append("../")
jieba.load_userdict("words_filter.txt")

import jieba.posseg as pseg
import jieba.analyse
from optparse import OptionParser

word_list=[]
word_value=[]

for line in open('keywords.txt'):
	tmp=line.split()
	word_list.append(tmp[0])
    #print tmp[0]

id_list1=[]
id_list2=[]
id_list=[]
id_list3=[]
id_test=[]
for line in open("id_test.txt"):
    id_test.append(line.split()[0])
for line in open("id_news.txt"):
    id_list.append(line.split()[0])
for line in open("id_news1.txt"):
    id_list1.append(line.split()[0])
for line in open("id_news2.txt"):
    id_list2.append(line.split()[0])
for line in open("id_news3.txt"):
    id_list3.append(line.split()[0])
def cal_wordfrequency(cur,word_list,id_list):


    f= open('test_vector.txt', 'w+')
    i=0
    for id in id_list:   
        i=i+1
        dict_words={}
        for tmp in word_list:
            dict_words[tmp]=0       
        cur.execute("select title from t_lable_group_comp where id='%s' "%(id)) 
        items=cur.fetchone()
        if type(items[0])!=type(None):
            tmps=jieba.cut(items[0].encode('utf8'))
            for tmp in tmps:
              
                keywords=dict_words.keys()
                if tmp=='爆炸':
                    print dict_words.has_key('爆炸')
                    print dict_words.has_key('爆炸')
                    print tmp
                    break
             
                if dict_words.has_key(tmp):  
                    print tmp

                    dict_words[tmp]=dict_words[tmp]+1      
                else:
                    pass
        for tmp in word_list:
            f.write(str(dict_words[tmp])+' ')

        f.write('\n')
       
def cal_wordscount(conn,id_list):
    cur=conn.cursor()
    f= open('news_wordscount.txt', 'w')
    i=0
    for id in id_list:        
        cur.execute("select segresult from t_lable_group_comp where id='%s' "%(id)) 
        items=cur.fetchone()
        tmps=items[0].encode('utf8').split()
        f.write(str(len(tmps)))
        f.write('\n')     

try:    
    conn=mdb.connect(host='localhost',
                     user='root',
                     passwd='',
                     db='oldcomp',
                     charset='utf8')
    cur=conn.cursor()
    cal_wordfrequency(cur,word_list,id_list)
  #  cal_wordscount(conn,id_list)
    
   # for data in datas:
  #     print "Database :%s"%data[0].encode("utf-8") 
  
finally:   









    if conn:
        conn.close()