# coding=utf-8
import sys
import MySQLdb as mdb
import nltk
import operator
import codecs
import random


id_list=[]

for line in open("baokong_id.txt"):
    id_list.append(line.split()[0])
id_indexs=[]


try:    
    conn=mdb.connect(host='localhost',
                     user='root',
                     passwd='',
                     db='comp',
                     charset='utf8')
    cur=conn.cursor() 
    # output1 = open('sample_news3.txt', 'a')
    # output2 = open('sample_news2.txt', 'w+')
    f = open('day_title.txt', 'w')
 #   f1=open('word_num_sort_id.txt','w')
    for id in id_list:
        
        cur.execute("select release_date_day,title from t_lable_group_comp where id='%s' "%(id))  
       
        #f.write(id_list[id_index-1]+'\n')
        items=cur.fetchone()
        if type(items)!=type(None):
            f.write(str(items[0])+' ')
            if type(items[1])!=type(None):
                f.write(items[1].encode('utf8').strip('\n')+'\n')               
            else:
                f.write('None.\n')
        else:
            f.write('None.\n')
       

#        print id_index
    f.close()
 

        
 

    #list_len=len(id_list)
    # for id_word in range(1):      
    #     cur.execute("select segresult from t_lable_group_comp where id='%s' "%(id_list[id_word]))   
    #     items=cur.fetchone()
    #     tmps=items[0].encode('utf8').split()
    #     for tmp in tmps:
    #         tmp1=nltk.tag.str2tuple(tmp)
    #         if dict_words.has_key(tmp1[0]):
    #             dict_words[tmp1[0]]=dict_words[tmp1[0]]+1
    #         else:
    #             dict_words[tmp1[0]]=1

    #     if id_word%1000==0:
    #         print id_word

finally:   
    if conn:
        conn.close()
